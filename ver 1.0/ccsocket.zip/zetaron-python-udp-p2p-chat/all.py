import ccsocket as socket
import hashlib, struct, Queue, threading, select, datetime

class Packet(object):
	def __init__(self, connection, handlerId, data):
		self.address = connection
		self.handlerId = handlerId
		self.data = data
		self.tries = 0
		self.last_sent = 0
		self.verified = False
		self.hash = hashlib.sha224(self.pack()).hexdigest()
		
	def pack(self):
		return (struct.pack(">h", self.handlerId) + str(self.data).encode())

class Peer(object):
    def __init__(self, addr, id):
        self.address = addr
        self.id = id

class P2P(object):
	def __init__(self, port = 3333):
		self.sock = socket.socket(socket.AF_INET6,socket.SOCK_DGRAM)
		self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		self.sock.bind(('', port))
		self.port = port
		
		self.handler = []
		self.packetHandler = {}		#{1:[callback1,callback2],2:[callback4],3:[callback1,callback4]}
		self.send_queue = Queue.Queue()
		self.out_queue = Queue.Queue()
		self.data_out = []

		self.receiveThread = ReceiveThread(self.sock, self)
		self.sendThread = SendThread(self.sock, self.send_queue, self.out_queue, self.data_out)
		self.watchThread = WatchThread(self.out_queue, self.send_queue, self.data_out)
		
		self.receiveThread.start()
		self.sendThread.start()
		self.watchThread.start()
		
		self.addHandler(VerifyHandler(self))

	def stop(self):
		self.receiveThread.stop()
		self.sendThread.stop()
		self.watchThread.stop()
		self.sock.close()
	
	def close(self):
		self.stop()
	
	def __del__(self):
		self.stop()
	
	def addHandler(self, handler):
		self.handler.append(handler)

	def handle(self, packet):
		if packet.handlerId in self.packetHandler:
			for callback in self.packetHandler[packet.handlerId]:
				callback(packet)
	
	def send(self, packet):
		self.send_queue.put(packet)

class ReceiveThread(threading.Thread):
	def __init__(self, sock, p2p):
		self.sock = sock
		self.p2p = p2p
		
		threading.Thread.__init__(self)
    
	def stop(self):
		self.running = 0
    
	def run(self):
		self.running = 1
		self.sock.settimeout(0.5)
		while self.running:
			try:
				data, addr = self.sock.recvfrom(1024)
				handlerId, = struct.unpack(">h", data[:2])
				pkt_data = str(data[2:])
				packet = Packet(addr, handlerId, pkt_data)
				
				if packet.handlerId != Types.VERIFYHANDLER:
					self.p2p.send(Packet(addr, Types.VERIFYHANDLER, packet.hash))
                
				self.p2p.handle(packet)		
			except:
				pass

class SendThread(threading.Thread):
	def __init__(self, socket, send_queue, out_queue, data_out):
		self.socket = socket
		self.send_queue = send_queue
		self.out_queue = out_queue
		self.data_out = data_out
		
		threading.Thread.__init__(self)
		
	def stop(self):
		self.running = 0
		
	def run(self):
		self.running = 1
		while self.running:
			packet = self.send_queue.get(True)
			self.socket.sendto(str(packet.pack()), packet.address)
			if packet.handlerId != Types.VERIFYHANDLER:
				packet.last_sent = datetime.datetime.now()
				packet.tries += 1
				self.out_queue.put(packet)
				self.data_out.append(packet)

class WatchThread(threading.Thread):
	def __init__(self, out_queue, send_queue, data_out):
		self.out_queue = out_queue
		self.send_queue = send_queue
		self.data_out = data_out
		
		threading.Thread.__init__(self)
		
	def stop(self):
		self.running = 0
		
	def run(self):
		self.running = 1
		while self.running:
			packet = self.out_queue.get(True)
			if packet.verified == False:
				if packet.tries < 4:
					if  (datetime.datetime.now() - packet.last_sent).seconds >= 3:
						self.send_queue.put(packet)
						self.data_out.remove(packet)
					else:
						self.out_queue.put(packet)

def enum(**enums):
	return type('Enum', (), enums)
	
Types = enum(
	VERIFYHANDLER = 1,
	MESSAGEHANDLER = 2
)

class Handler(object):
	def __init__(self, p2p, *args):
		self.p2p = p2p
		self.onEnable(p2p, *args)
		
	def onEnable(self):
		pass
		
	def register(self, id, callback):
			if id in self.p2p.packetHandler:
				self.p2p.packetHandler[id].append(callback)
			else:
				self.p2p.packetHandler[id] = [callback]
		
	def getSentPacket(self, packet):
		for pkt in self.p2p.data_out:
			if pkt.hash == packet.data:
				return pkt

class ChatPeerHandler(Handler):
    def onEnable(self, p2p, chat):
        self.chat = chat
        self.p2p = p2p
        self.register(3,self.onPeerHandshakePacket)
        
    def onPeerHandshakePacket(self, packet):
        peer = Peer(packet.address, packet.data)
        
        if(peer.id in self.chat.peers):
            print("Peer already in peerlist.")
        else:
            print("New Peer: {0}".format(peer.id))
            self.chat.peers[peer.id] = peer
            self.chat.addList(peer.id)
            self.p2p.send(Packet(peer.address , 3, self.chat.nickname))

class MessageHandler(Handler):
    def onEnable(self, p2p, chat):
        self.chat = chat
        self.register(2,self.onMessage)

    def onMessage(self, packet):
        peerdata = packet.data.split(':', 1)
        self.chat.addMessage(peerdata[0], peerdata[1])

class VerifyHandler(Handler):
	def onEnable(self, p2p):
		self.register(1,self.handle)
		
	def handle(self, packet):
		toHandle = self.getSentPacket(packet)
		toHandle.verified = True
		print("ACK:{0}".format(toHandle.handlerId))