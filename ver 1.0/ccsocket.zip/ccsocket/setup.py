#! /usr/bin/env python

"""
Distutils setup file for ccsocket.
"""

from distutils.core import setup

setup(
name = 'ccsocket',
packages = ['ccsocket'],
version = '0.1.0',
description = 'IP6 covert chanel socket api',
author='Tomas Dragoun',
author_email = 'drakoviens(at)gmail.com',
license = 'BSD-3-Clause',
keywords = ["covert channels", "ip6", "socket"],
classifiers = ['Programming Language :: Python :: 2.7',
               'Operating System :: Linux',
               'License :: OSI Approved :: GPLv3',
               'Development Status :: Alpha',
               'Topic :: Internet :: Security',
               'Intended Audience :: System Administrators', ]
)
